import { defineConfig } from 'astro/config';
import tina from '@tina/toolkit/plugin';

export default defineConfig({
  integrations: [tina()],
});